
let i = 1; 
function contadormas(){ 
    i = i + 1; 
    let cant = document.getElementById("counter"); 
    cant.value = i;
    if(cant.value == 1){
            i=1;
            cant.value="1";
    }
}
function contadormenos(){ 
    if(i>=2){
        i = i - 1; 
        let cant = document.getElementById("counter"); 
        cant.value = i;
        if(cant.value == 1){
            i=1;
            cant.value="0";
        }

    }
}

function total(){


    let precio =document.getElementById("precio");
    precio=20;
    let total = precio.value*cant.value;
    

    }
    


        function $(id)
        {
            return document.getElementById(id);
        }

        function increase()
        {

            $('counter').value = parseInt($('counter').value) + 1;
            let mas = document.querySelector("#mas");
            mas.addEventListener('click', (evt) => {
            // aqui  todo lo que hará cuando se de click en mas
            
            var precio = document.getElementById("precio").value;
            var counter = document.getElementById("counter").value;
            var result = document.getElementById("result").value;          
            var multi = parseInt(precio.value) * parseInt(counter.value);
            document.getElementById("result").innerHTML=multi;
            })

        }

        function decrease()
        {

            var counterValue = parseInt($('counter').value);
            var newCounterValue = (counterValue)
                ? counterValue - 1
                : 0;

            $('counter').value = newCounterValue;
            let menos = document.querySelector("#menos");
            menos.addEventListener('click', (evt) => {
            // aqui  todo lo que hará cuando se de click en mas
            
            var precio = document.getElementById("precio").value;
            var counter = document.getElementById("counter").value;
            var result = document.getElementById("result").value;          
            var multi = parseInt(precio.value) * parseInt(counter.value);
            document.getElementById("result").innerHTML=multi;
            })

        }

        

    
        function res() {    

            var precio = document.getElementById("precio").value;
            var counter = document.getElementById("counter").value;
            var result = document.getElementById("result").value;          
            var multi = parseInt(precio.value) * parseInt(counter.value);
            document.getElementById("result").innerHTML=multi;

                
        }
        