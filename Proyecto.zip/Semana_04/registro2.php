<!DOCTYPE html>
<html>
<head>
	<title>Registrar usuario</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="estilo_01.css">
	<link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="Css/estilos.css" />
    <link rel="stylesheet" href="Css/estilos2.css" />
    <link rel="stylesheet" href="Css/animacion2.css" />

    <script src="js/Total.js"></script>
    <link href="css/hover.css" rel="stylesheet" media="all">

  </head>
  <body>
    <!--Encabezado-->
    <header>
      <div class="container1">
        <center><h1 class="fst-italic">Two Ticket</h1></center>
        <a href="index.php" class="fst-italic" class="button" >Inicio</a>
      </div>
    </header>
</head>
<body>
    <form method="post">

    	<input type="text" name="nombre" placeholder="Nombre completo">
    	<input type="text" name="apellido" placeholder="Apellidos">
		<input type="text" name="usuario" placeholder="Usuario">
		<input type="password" name="contraseña" placeholder="Contraseña">
		<input type="email" name="correo" pattern="[a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*@[a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*[.][a-zA-Z]{1,5}" placeholder="Correo">
    	<input type="submit" name="register">
    </form>
        <?php 
        include("registrar.php");
        ?>
</body>
</html>