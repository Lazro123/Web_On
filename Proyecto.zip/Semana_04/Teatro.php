<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Teatro</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="Css/estilos.css" />
    <link rel="stylesheet" href="Css/animacion2.css" />
    <link href="css/hover.css" rel="stylesheet" media="all">
  </head>
  <body>
    <!--Encabezado-->
    <header>
      <div class="container">
        <center><h1 class="fst-italic">Two Ticket</h1></center>
        <a href="index.php" class="fst-italic" class="button" >Inicio</a>
      </div>
    </header>
    <aside class="responsive-banner" id="banner">
  
      <ul class="slider">
        <li id="slide1">
          <img src="imagenes/rosa.jpg"/>
        </li>
        <li id="slide2">
          <img src="imagenes/yu.jpg"/>
        </li>
        <li id="slide3">
          <img src="imagenes/bi.jpg"/>
        </li>
      </ul>
      
      <ul class="menu">
        <li>
          <a href="#slide1">1</a>
        </li>
        <li>
          <a href="#slide2">2</a>
        </li>
         <li>
          <a href="#slide3">3</a>
        </li>
      </ul>
      

    </div>
    </aside>
    <div class="row">
      <div class="column">
        <div class="card2">
          <a href="Teatro_ex.html"><img class="card-img" src="img_teatro/3.jpg"></a>
          <h5 class="card-title">LA CARTA QUE NUNCA LE ESCRIBISTE A TU EX

          </h5>
            <p class="card-text">Fecha
              jueves 9 de Diciembre, 2021
            <br>
            horario: 07:30 pm

            <br>
            Entrada Individual
            S/ 35.00
            <br>
 
            <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
        </div>
      </div>
    
      <div class="column">
        <div class="card2">
          <a href="Teatro_Amor.html"><img class="card-img" src="img_teatro/w.jpg" alt="Card image cap"></a>

          <h5 class="card-title">AMOR DE VERANO</h5>
          <p class="card-text"> Fecha:
            Viernes 12 de Noviembre, 2021
            <br>
            Horario
            08:00 PM
            <br>
            Entradas:        
            GENERAL "REBELDE"
            S/ 30.00
            <br>
           
          <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
        </div>
      </div>
      
    <div class="column">
        <div class="card2">
          <a href="Teatro_claveles.html"><img class="card-img" src="img_teatro/4.jpg" ></a>

            <h5 class="card-title">El Cabeza De Claveles</h5>
            <p class="card-text">Fecha:
            Viernes 17 de Diciembre, 2021
            <br>
            Horario
            09:00 PM
            <br>
            Entradas
            Individuales
            S/ 50.00
            <br>

            <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
        </div>
      </div>
    <footer class="text center">
      <div class="card text-center">
        <div class="card-header">
          Two Ticket
        </div>
        <div class="card-body">

          <a href="https://www.facebook.com/"><img src="imagenes/fb.png" width="50" height="50" HSPACE="10" VSPACE="10"></a>
          <a href="https://twitter.com/home?lang=es"><img src="imagenes/tw.png" width="50" height="50" HSPACE="10" VSPACE="10"></a>
          <a href="https://www.instagram.com/"><img src="imagenes/ig.png" width="50" height="50" HSPACE="10" VSPACE="10"></a>
          <p >Sobre Nosotros</p>
          <p >FAQ</p>
          <p >Libro de reclamaciones</p>
          
        </div>
        <div class="card-footer text-muted">
            Copyright @2021 - 
        </div>
      </div>
    </footer>