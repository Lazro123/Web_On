<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Deportes</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="Css/estilos.css" />
    <link rel="stylesheet" href="Css/animacion2.css" />
    <link href="css/hover.css" rel="stylesheet" media="all">
  </head>
  <body>
    <!--Encabezado-->
    <header>
      <div class="container">
        <center><h1 class="fst-italic">Two Ticket</h1></center>
        <a href="index.php" class="fst-italic" class="button" >Inicio</a>
      </div>
    </header>
    <aside class="responsive-banner" id="banner">
  
      <ul class="slider">
        <li id="slide1">
          <img src="IMG_DEPORTES/binacional.jpg"/>
        </li>
        <li id="slide2">
          <img src="IMG_DEPORTES/peru_bolivia.jpg"/>
        </li>
        <li id="slide3">
          <img src="IMG_DEPORTES/Garcilaso_inca.jpg"/>
        </li>
      </ul>
      
      <ul class="menu">
        <li>
          <a href="#slide1">1</a>
        </li>
        <li>
          <a href="#slide2">2</a>
        </li>
         <li>
          <a href="#slide3">3</a>
        </li>
      </ul>
      
      <div class="row" id="resultados">
  
      <!--  
        <div class="column">
          <div class="card2">
            <a href="Deportes_Cienciano.html"><img class="card-img" src="imagenes/gar.png"></a>
            <h5 class="card-title">CIENCIANO DEL CUZCO VS ATLETICO GRAU</h5>
              <p class="card-text">Fecha
                DOMINGO 15 DE MARZO, 2022
              <br>
              Horario
              03:00 PM
              <br>
              Entradas:
              OCCIDENTE	
              S/. 25.00

              </p></p>
              <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
          </div>
        </div>
  
        <div class="column">
          <div class="card2">
            <a href="Deportes_Alianza.html"><img class="card-img" src="imagenes/al.png" alt="Card image cap"></a>
  
            <h5 class="card-title">ALIANZA LIMA VS DEPORTIVO BINACIONAL
            </h5>
            <p class="card-text"> Fecha
              DOMINGO 3 DE MARZO , 2022              <br>
              Horario
              04:00 PM
              <br>
              ENTRADAS:
              ORIENTE	S/. 40.00
              <br>

            <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
          </div>
        </div>
        
        <div class="column">
            <div class="card2">
              <a href="Deportes_Peru.html"><img class="card-img" src="IMG_DEPORTES/peru-vs-bolivia-en-vivo.jpg" ></a>
  
                <h5 class="card-title">PERU VS BOLIVIA
                </h5>
                <p class="card-text">Fecha
                  JUEVES 11 de Noviembre, 2021
                  
                <br>
                Horario
                09:00 PM
                <br>
                Entradas
                Sur	S/. 99
                <br>
                <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
            </div>
          </div>
-->
    </div>
    <footer class="text center">
      <div class="card text-center">
        <div class="card-header">
          Two Ticket
        </div>
        <div class="card-body">

          <a href="https://www.facebook.com/"><img src="imagenes/fb.png" width="50" height="50" HSPACE="10" VSPACE="10"></a>
          <a href="https://twitter.com/home?lang=es"><img src="imagenes/tw.png" width="50" height="50" HSPACE="10" VSPACE="10"></a>
          <a href="https://www.instagram.com/"><img src="imagenes/ig.png" width="50" height="50" HSPACE="10" VSPACE="10"></a>
          <p >Sobre Nosotros</p>
          <p >FAQ</p>
          <p >Libro de reclamaciones</p>
        </div>
        <div class="card-footer text-muted">
            Copyright @2021 - 
        </div>
      </div>
    </footer>
    
    <script>

        let resultados = document.getElementById('resultados');

        fetch('./api.php').then(respuesta => {
                respuesta.text().then(text =>{

                  const datos = JSON.parse(text);
                  console.log(datos);
                  datos.forEach(Deportes =>{

                  resultados.insertAdjacentHTML('beforeend',`<div class="column">
                  <div class="card2">
                  <a href="${Deportes[2]}.html"><img class="card-img" src="IMG_DEPORTES/${Deportes[3]}.jpg" ></a>

                    <h5 class="card-title">${Deportes[1]}
                    </h5>
                    <p class="card-text">Fecha: 
                    ${Deportes[4]}
                      
                    <br>
                    Horario:
                    ${Deportes[5]}
                    <br>
                    Entradas
                    Sur	S/.${Deportes[6]}
                    <br>
                    <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
                    </div>
                    </div>` )

                    })  
                })
                
            })
      </script>