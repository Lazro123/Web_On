<?php 

include("con_db.php");

if ($result = $conex->query("SELECT * FROM musica")) {
    
    echo json_encode($result->fetch_all());
}
