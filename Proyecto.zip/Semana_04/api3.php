<?php 

include("con_db.php");

if ($result = $conex->query("SELECT * FROM cine")) {
    
    echo json_encode($result->fetch_all());
}
