<!DOCTYPE html>
<html>
<head>
	<title>Registrar usuario</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="estilo_01.css">
</head>
<body>
    <form method="post">

    	<input type="text" name="nombre" placeholder="Nombre completo">
    	<input type="text" name="apellido" placeholder="Apellidos">
		<input type="text" name="usuario" placeholder="Usuario">
		<input type="password" name="contraseña" placeholder="Contraseña">
		<input type="email" name="correo" placeholder="Correo">
    	<input type="submit" name="register">
    </form>
        <?php 
        include("registrar.php");
        ?>
</body>
</html>