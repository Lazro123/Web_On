<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Cine</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="Css\estilos.css" />
    <link rel="stylesheet" href="Css\estilos2.css" />
    <link rel="stylesheet" href="Css\animacion2.css" />
    
    <script src="js\Total.js"></script>
    <link href="Css\hover.css" rel="stylesheet" media="all">
  
  </head>
  <body>
    <!--Encabezado-->
    <header>
      <div class="container1">
        <center><h1 class="fst-italic">Two Ticket</h1></center>
        
        <a href="../index.php" class="fst-italic" class="button" >Cerrar Sesion</a>
        
        <img src="imagenes/login2.png" style="text-align,float:right" >
      </div>
    </header>

  <!--BOTONES-->
      <br>
        <div class="row" >

        <div class="col-md-12" >
          <center id="resultados">
         <!-- <a href="Teatro.html"><button type="button" class="btn btn-secondary btn-lg  hvr-sweep-to-right">Teatro</button></a>
          <a href="Musica.html"> <button type="button" class="btn btn-secondary btn-lg  hvr-sweep-to-right">Musica</button></a>
          <a href="Cine.php"> <button type="button" class="btn btn-secondary btn-lg  hvr-sweep-to-right">Cine</button></a>
          <a href="Deportes.php"> <button type="button" class="btn btn-secondary btn-lg  hvr-sweep-to-right">Deportes</button></a>
          <a href="Comedia.php"> <button type="button" class="btn btn-secondary btn-lg  hvr-sweep-to-right">Comedia</button></a>
-->
        </center>
        </div>
      </div>
      <br>

      <!--COLUMNAS-->
      <div class="row">
        <div class="color-impar col-md-3">
          <h1>Franco Escamilla en Lima</h1>
          <p>
            Uno de los mejores comediantes del mundo llegara a Lima en Noviembre de este año.
            Podras adquirir tus entradas desde el 20 de Octubre.
          </p>
        </div>
        <div class="col-md-3">
          <h1><strong> Descuento especial con Visa</strong></h1>
          <p>
            Recuerda que si adquieres tus entradas con tu tarjeta VISA, tendras un descuento
            del 10% en el evento de tu preferencia. Aplica para cualquier compra realizada.
          </p>
        </div>
        <div class="color-impar col-md-3">
          <h1>Promoción Especial</h1>
            <p>
              Para cualquier evento de la seccion Comedia obtendras un descuento
              del 20% adicional a cualquier descuento aplicado.
            </p>
          </div>
        <div class="col-md-3">
            <h1><strong> Siguenos en nuestras redes</strong></h1>
              <p>
                Para que estes al tanto de los eventos mas esperados a nivel nacional
                recuerda seguirnos en nuestras redes sociales. 
              </p>
          </div>
      </div>
    </div>
    <br>

    
      <!--IMAGEN- RADIOBUTTON-->
      <center><div class="contenedor">
        <div class="row">
          <img src="imagenes/wallpapertip_1080p-live-wallpaper_817153.jpg" class="img-fluid" alt="bosque">
        </div>
        <div class="texto"><strong> Lo que fue ...</strong></div>
        <div class="centrado" ><strong> Aqui puedes apreciar todos los eventos que se realizaron el ultimo mes,
          todos los estrenos de los eventos mas esperados realizados, opinión del publico, reacciones y mas.
          Recuerda que te traeremos los mejores y mas esperados eventos del medio. </strong>
        </div>
      </div></center>
      <!--VIDEOS-->
        
          <div class="color-impar col-md-3">
              <h1>Te perderas esto? </h1>
            </div>
            <div class="row row-cols-1 row-cols-md-3 g-4">
              <div class="col">
                <div class="card">
                  <iframe width="420" height="315" src="https://www.youtube-nocookie.com/embed/D_Tf4iR_Qgs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>                  
                  <div class="card-body"> 
                    <h5 class="card-title">GIANMARCO ACUSTICO – Gira Nacional 2021</h5>
                    <a href="Musica_Gianmarco.html"><p class="card-text">ir al evento!</p></a>
                  </div>
                </div>
              </div>
              <div class="col">
                <div class="card">
                  <iframe width="420" height="315" src="https://www.youtube-nocookie.com/embed/F4Ygcigj0Gk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                  <div class="card-body"> 
                  <h5 class="card-title">Venom 2</h5>
                    <a href="Cine_Venom.html"><p class="card-text">ir al evento!</p></a>
                  </div>
                </div>
              </div>
              <div class="col">
                <div class="card">
                  <iframe width="450" height="315" src="https://www.youtube.com/embed/iL1OtEUB2JM" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                  <div class="card-body"> 
                  <h5 class="card-title">Peru vs Bolivia</h5>
                    <a href="Deportes_Peru.html"><p class="card-text">ir al evento!</p></a>
                  </div>
                </div>
              </div>
            </div>
        <!--Pie de pagina-->
        <footer class="text center">
          <div class="card text-center">
            <div class="card-header">
              Two Ticket
            </div>
            <div class="card-body">

              <a href="https://www.facebook.com/"><img src="imagenes/fb.png" width="50" height="50" HSPACE="10" VSPACE="10"></a>
              <a href="https://twitter.com/home?lang=es"><img src="imagenes/tw.png" width="50" height="50" HSPACE="10" VSPACE="10"></a>
              <a href="https://www.instagram.com/"><img src="imagenes/ig.png" width="50" height="50" HSPACE="10" VSPACE="10"></a>
              <a href="Nosotros.html"><p >Sobre Nosotros</p></a>
              <a href="faq.html"><p >FAQ</p></a>
              <A href="LibroReclamacion.html"><p >Libro de reclamaciones</p></A>
              
            </div>
            <div class="card-footer text-muted">
                Copyright @2021 - 
            </div>
          </div>
        </footer>

        <script
          src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
          integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
          crossorigin="anonymous"
        ></script>
      </body>
    </html>

    <script>

        let resultados = document.getElementById('resultados');

        fetch('./apiCategoria.php').then(respuesta => {
                respuesta.text().then(text =>{

                  const datos = JSON.parse(text);
                  console.log(datos);
                  datos.forEach(Categorias =>{

                  resultados.insertAdjacentHTML('beforeend', `
                  <a href="${Categorias[1]}.php"><button type="button" class="btn btn-secondary btn-lg  hvr-sweep-to-right">${Categorias[1]}</button></a>` )

                    })  
                })
                
            })
      </script>
