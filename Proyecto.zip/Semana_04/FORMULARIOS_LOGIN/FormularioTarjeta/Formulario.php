<?php 

include("conect.php");

if (isset($_POST['enviar'])) {
	    $numero = ($_POST['NumeroTarjeta']);
	    $nombre = trim($_POST['Nombre']);
	    $mes = trim($_POST['Mes']);
        $año = trim($_POST['Año']);
        $ccv = trim($_POST['ccv']);

        $consulta = "INSERT INTO pago(NumeroTarjeta,Nombre,Mes,Año,ccv) VALUES ('$numero','$nombre','$mes','$año','$ccv')";
	    $resultado = mysqli_query($conex,$consulta);
	    if ($resultado) {
	    	?> 
			<script>
	    	alert("PAGO REGISTRADO CON EXITO!")
			</script>
			<?php
				header("location:..\index2.php");
				
				?>
			
           <?php
	    } else {
	    	?> 
	    	<script>
	    		alert("Error")
			</script>
           <?php
	    }
    }   
	?>