<?php

$correo=$_POST['correo'];
$contraseña=$_POST['contraseña'];
session_start();
$_SESSION['contraseña']=$contraseña;
$conexion=mysqli_connect("localhost","root","","twoticket");

$consulta = "SELECT * FROM registro where correo = '$correo' and contraseña = '$contraseña' ";
$resultado=mysqli_query($conexion,$consulta);

$filas=mysqli_num_rows($resultado) ;

if($filas){
    ?>
    <script>
       alert("Hola")
    </script>
    <?php
    header("location:index2.php");
    
    ?>

    <?php


}
else{
    ?>
    <script>
       alert("Correo o contraseña incorrecta :c")
    </script>
    <?php
    
    include("login.html");
    
    ?>

    <?php
}

mysqli_free_result($resultado);
mysqli_close($conexion);
