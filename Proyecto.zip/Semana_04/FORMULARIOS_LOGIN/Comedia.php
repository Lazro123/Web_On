<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Comedia</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="Css/estilos.css" />
    <link rel="stylesheet" href="Css/animacion2.css" />
    <link href="css/hover.css" rel="stylesheet" media="all">
  </head>
  <body>
    <!--Encabezado-->
    <header>
      <div class="container1">
        <center><h1 class="fst-italic">Two Ticket</h1></center>
        <a href="index2.php" class="fst-italic" class="button" >Inicio</a>
      </div>
    </header>
    <aside class="responsive-banner" id="banner">
        <ul class="slider">
          <li id="slide1">
            <img src="imagenes/FrancoEscamilla_1.jpg"/>
          </li>
          <li id="slide2">
            <img src="imagenes/hablando.jpg"/>
          </li>
          <li id="slide3">
            <img src="imagenes/tobi.jpg"/>
          </li>
        </ul>
        
        <ul class="menu">
          <li>
            <a href="#slide1">1</a>
          </li>
          <li>
            <a href="#slide2">2</a>
          </li>
           <li>
            <a href="#slide3">3</a>
          </li>
        </ul>
        
      </div>
    </aside>
      <div class="row" id="resultados">
        
      <!--  <div class="column">
          <div class="card2">
            <a href="Comedia_will.html"><img class="card-img" src="img_comedia/1.jpg"></a>
            <h5 class="card-title">No Hay Mal Que X Will No Venga</h5>
              <p class="card-text">Fecha:
              Viernes 12 de Noviembre, 2021
              <br>
              Horario
              09:00 PM
              <br>
              Entradas
              Individual
              S/ 15.00</p></p>
              <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
          </div>
        </div>
      
        <div class="column">
          <div class="card2">
            <a href="Comedia_p.html"><img class="card-img" src="img_comedia/p.jpg" alt="Card image cap"></a>

            <h5 class="card-title"> PATRIA en Trujillo</h5>
            <p class="card-text"> Fecha:
              16 de Diciembre, 2021
              <br>
              Horario
              08:00 PM
              <br>
              Entradas
              Individual
              S/ 40.00</p></p>
            <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
          </div>
        </div>
        
      <div class="column">
          <div class="card2">
            <a href="Comedia_Par.html"><img class="card-img" src="img_comedia/act61495a4b95f1a.jpg" ></a>

              <h5 class="card-title">Par de Cojudos</h5>
              <p class="card-text">Fecha:
              Viernes 12 de Noviembre, 2021
              <br>
              Horario
              09:00 PM
              <br>
              Entradas
              Individual
              S/ 40.00</p></p>
              <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
          </div>
    -->    </div>

        <footer class="text center">
          <div class="card text-center">
            <div class="card-header">
              Two Ticket
            </div>
            <div class="card-body">
    
              <a href="https://www.facebook.com/"><img src="imagenes/fb.png" width="50" height="50" HSPACE="10" VSPACE="10"></a>
              <a href="https://twitter.com/home?lang=es"><img src="imagenes/tw.png" width="50" height="50" HSPACE="10" VSPACE="10"></a>
              <a href="https://www.instagram.com/"><img src="imagenes/ig.png" width="50" height="50" HSPACE="10" VSPACE="10"></a>
              <p >Sobre Nosotros</p>
              <p >FAQ</p>
              <p >Libro de reclamaciones</p>
              
            </div>
            <div class="card-footer text-muted">
                Copyright @2021 - 
            </div>
          </div>
        </footer>


          <script>
            
            let resultados = document.getElementById('resultados');

            fetch('./api2.php').then(respuesta => {
                    respuesta.text().then(text =>{

                      const datos = JSON.parse(text);
                      console.log(datos);
                      datos.forEach(Comedia =>{

                      resultados.insertAdjacentHTML('beforeend',`<div class="column">
                      <div class="card2">
                      <a href="${Comedia[2]}.html"><img class="card-img" src="img_comedia/${Comedia[3]}.jpg" ></a>

                        <h5 class="card-title">${Comedia[1]}
                        </h5>
                        <p class="card-text">Fecha: 
                        ${Comedia[4]}
                          
                        <br>
                        Horario:
                        ${Comedia[5]}
                        <br>
                        Entradas
                        Sur	S/.${Comedia[6]}
                        <br>
                        <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>

                      </div>
                      </div>` )

                          })  
                        })
                        
                    })
            </script>