

function total(){


    let precio =document.getElementById("precio");
    precio=20;
    let total = precio.value*cant.value;
    

    }
    


        function $(id)
        {
            return document.getElementById(id);
        }

        function increase()
        {

            $('counter').value = parseInt($('counter').value) + 1;
            let mas = document.querySelector("#mas");
            mas.addEventListener('click', (evt) => {
            // aqui  todo lo que hará cuando se de click en mas
            
            var precio = document.getElementById("precio").value;
            var counter = document.getElementById("counter").value;
            var result = document.getElementById("result").value;          
            var multi = parseInt(precio.value) * parseInt(counter.value);
            document.getElementById("result").innerHTML=multi;
            })

        }

    