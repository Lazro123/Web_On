

function multiplicar(){
    id = document.getElementById("id").value;
    monto = document.getElementById("monto").value;
    let r = id*monto;
    document.getElementById("resultado").onclick=function(){
        
    }
  }