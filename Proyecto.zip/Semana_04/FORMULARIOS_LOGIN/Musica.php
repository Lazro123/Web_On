<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Musica</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="Css/estilos.css" />
    <link rel="stylesheet" href="Css/animacion2.css" />
    <link href="css/hover.css" rel="stylesheet" media="all">
  </head>
  <body>
    <!--Encabezado-->
    <header>
      <div class="container">
        <center><h1 class="fst-italic">Two Ticket</h1></center>
        <a href="index2.php" class="fst-italic" class="button" >Inicio</a>
      </div>
    </header>
    <aside class="responsive-banner" id="banner">
  
      <ul class="slider">
        <li id="slide1">
          <img src="imagenes/gian.jpg" />
        </li>
        <li id="slide2">
          <img src="imagenes/libido.jpg"/>
        </li>
        <li id="slide3">
          <img src="imagenes/rio.jpg"/>
        </li>
      </ul>
      
      <ul class="menu">
        <li>
          <a href="#slide1">1</a>
        </li>
        <li>
          <a href="#slide2">2</a>
        </li>
         <li>
          <a href="#slide3">3</a>
        </li>
      </ul>
      
    </div>
    <div class="row">
      <div class="column">
        <div class="card2">
          <a href="Musica_Gianmarco.html"><img class="card-img" src="img_musica/gian.jpg"></a>
          <h5 class="card-title">GIANMARCO ACUSTICO – Gira Nacional 2021</h5>
            <p class="card-text">Fecha
              Viernes 10 de Diciembre, 2021
            <br>
            Horario
            09:00 PM
            <br>
            Entrada general:
            S/ 100.00</p></p>
            <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
        </div>
      </div>

      <div class="column">
        <div class="card2">
          <a href="Musica_Libido.html"><img class="card-img" src="img_musica/l.jpg" alt="Card image cap"></a>

          <h5 class="card-title">LIbido En Concierto - Barranco
          </h5>
          <p class="card-text"> Fecha
            Sábado 18 de Diciembre, 2021
            <br>
            Horario
            08:00 PM
            <br>
            
           Entrada general:
            S/ 55</p></p>
          <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
        </div>
      </div>
      
      <div class="column">
          <div class="card2">
            <a href="Musica_Versiones.html"><img class="card-img" src="img_musica/r2.jpg" ></a>

              <h5 class="card-title">Rio en el centro

              </h5>
              <p class="card-text">Fecha
                Sábado 06 de Noviembre, 2021
                <br>
              Horario
              10:00 PM
              
              <br>
              PREVENTA-GENERAL
              S/ 70.00
              <br>

              <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
          </div>
        </div>
        <footer class="text center">
            <div class="card text-center">
              <div class="card-header">
                Two Ticket
              </div>
              <div class="card-body">

                <img src="imagenes/fb.png" width="50" height="50" HSPACE="10" VSPACE="10">
                <img src="imagenes/tw.png" width="50" height="50"HSPACE="10" VSPACE="10">
                <img src="imagenes/ig.png" width="50" height="50"HSPACE="10" VSPACE="10">
                <p >Sobre Nosotros</p>
                <p >FAQ</p>
                <p >Libro de reclamaciones</p>
                
              </div>
              <div class="card-footer text-muted">
                  Copyright @2021 - 
              </div>
            </div>
          </footer>